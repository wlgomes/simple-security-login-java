package testingskills.copy;

public class Main {
	public static void main(String[] args) {
		
		UserData.idNumericLogin();
		UserData.idStringLogin();
		System.out.println(UserData.chosenNumericalID + UserData.chosenStringID);
	}
}
